---
layout: page
title: "Lab Technician"
---

Researcher - Physics & Astronomy

Some University - 1 Main Street, Canada

Phone: (000) 000-0000

Email: hello@university.edu

Office: Science Building 505

---

Nullam lacinia eros eu lectus efficitur euismod. Phasellus ac urna ligula. Curabitur a massa volutpat, convallis velit ut, varius nunc. Ut venenatis pellentesque nulla, luctus accumsan eros suscipit vitae. Proin odio neque, hendrerit cursus mattis ut, aliquet ut nulla. Nulla facilisi. Donec tempus rutrum libero vel cursus.
